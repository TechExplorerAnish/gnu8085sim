import { Button } from "@/components/ui/button"
import { FileText, RotateCcw, Play, Pause, SkipForward, Save, Printer, Settings, BugIcon as Debug } from 'lucide-react'

export function Toolbar() {
  return (
    <div className="border-b p-2 flex items-center gap-2">
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon">
          <FileText className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Save className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Printer className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Settings className="h-4 w-4" />
        </Button>
      </div>
      <div className="h-4 w-px bg-border" />
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon">
          <RotateCcw className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Play className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Pause className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <SkipForward className="h-4 w-4" />
        </Button>
      </div>
      <div className="h-4 w-px bg-border" />
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon">
          <Debug className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

