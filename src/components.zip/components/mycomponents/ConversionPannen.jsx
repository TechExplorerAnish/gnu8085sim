import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function ConversionPanel() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">Decimal - Hex Conversion</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm mb-1">Decimal</div>
            <Input type="text" className="font-mono" defaultValue="0" />
          </div>
          <div>
            <div className="text-sm mb-1">Hex</div>
            <Input type="text" className="font-mono" defaultValue="0" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="secondary" size="sm">To Hex</Button>
          <Button variant="secondary" size="sm">To Dec</Button>
        </div>
      </CardContent>
    </Card>
  )
}

