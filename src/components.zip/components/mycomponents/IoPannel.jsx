import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function IOPanel() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">I/O Ports</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="flex items-center gap-2">
          <Input type="text" className="w-16 font-mono" defaultValue="00" placeholder="Port" />
          <Button variant="outline" size="icon" className="w-8 h-8">-</Button>
          <Button variant="outline" size="icon" className="w-8 h-8">+</Button>
          <Input type="text" className="w-24 font-mono" defaultValue="00" placeholder="Value" />
        </div>
        <Button variant="secondary" size="sm">Update Port Value</Button>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>Input Port: 00</div>
          <div>Output Port: 00</div>
        </div>
      </CardContent>
    </Card>
  )
}

