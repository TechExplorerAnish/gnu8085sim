import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RegistersPanel } from "./RegisterPannel"
import { CodeEditor } from "./CodeEditor"
import { DataPanel } from "./DataPannel"
import { KeypadPanel } from "./KeypadPannel"
import { ConversionPanel } from "./ConversionPannen"
import { IOPanel } from "./IoPannel"
import { Toolbar } from "./Toolbar"
import { MemoryPanel } from "./MemoryPannel"

export default function Layout() {
  return (
    <div className="flex flex-col h-screen bg-background">
      <header>
        <Toolbar />
      </header>

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-64 border-r p-4 flex flex-col gap-4">
          <RegistersPanel />
          <ConversionPanel />
          <IOPanel />
        </aside>

        <main className="flex-1 flex flex-col">
          <CodeEditor />
        </main>

        <aside className="w-80 border-l">
          <Tabs defaultValue="data" className="h-full">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="data">Data</TabsTrigger>
              <TabsTrigger value="stack">Stack</TabsTrigger>
              <TabsTrigger value="keypad">KeyPad</TabsTrigger>
              <TabsTrigger value="memory">Memory</TabsTrigger>
              <TabsTrigger value="io">I/O Ports</TabsTrigger>
            </TabsList>
            <TabsContent value="data" className="h-[calc(100%-40px)]">
              <DataPanel />
            </TabsContent>
            <TabsContent value="keypad" className="h-[calc(100%-40px)]">
              <KeypadPanel />
            </TabsContent>
            <TabsContent value="memory" className="h-[calc(100%-40px)]">
              <MemoryPanel />
            </TabsContent>
            <TabsContent value="io" className="h-[calc(100%-40px)]">
              <IOPanel />
            </TabsContent>
          </Tabs>
        </aside>
      </div>
    </div>
  )
}

