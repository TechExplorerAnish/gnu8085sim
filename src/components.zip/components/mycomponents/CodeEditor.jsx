import { useState } from 'react';
import { ChevronRight } from 'lucide-react';

export function CodeEditor() {
  const [value, setValue] = useState(`;Program title\n\njmp start\n\n;data\n\n;code\nstart: nop\n\nhlt`);
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-6 bg-slate-50">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1">
            <label 
              htmlFor="loadAt" 
              className="block text-sm font-semibold text-slate-700 mb-2"
            >
              Load Address
            </label>
            <div className="relative">
              <input
                id="loadAt"
                type="text"
                className="w-full px-4 py-2 rounded-md border border-slate-200 
                         focus:ring-2 focus:ring-blue-500 focus:border-transparent
                         transition-all duration-200 outline-none"
                placeholder="Enter load address..."
              />
              <ChevronRight className="absolute right-3 top-2.5 text-slate-400" size={20} />
            </div>
          </div>
        </div>

        <div className="relative flex-1">
          <div className="absolute top-0 left-0 w-full h-8 bg-slate-100 
                        rounded-t-lg border-b border-slate-200">
            <div className="flex items-center h-full px-4">
              <div className="w-3 h-3 rounded-full bg-red-400 mr-2"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-400 mr-2"></div>
              <div className="w-3 h-3 rounded-full bg-green-400"></div>
            </div>
          </div>
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="w-full h-[calc(100vh-180px)] font-mono text-sm leading-relaxed
                     bg-slate-900 text-slate-100 p-6 pt-12 rounded-lg
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent
                     transition-all duration-200 outline-none resize-none"
            spellCheck="false"
          />
        </div>
      </div>
    </div>
  );
}

