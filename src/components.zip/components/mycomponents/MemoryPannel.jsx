import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function MemoryPanel() {
  const memoryData = Array.from({ length: 16 }, (_, i) => ({
    address: i.toString(16).padStart(4, '0').toUpperCase(),
    value: '00'
  }))

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Input type="text" className="w-24" placeholder="Address" />
        <Button variant="secondary" size="sm">Go To</Button>
      </div>
      <div className="grid grid-cols-2 gap-1">
        {memoryData.map((item) => (
          <div key={item.address} className="flex items-center gap-2">
            <div className="w-16 font-mono text-sm">{item.address}</div>
            <Input type="text" className="w-12 font-mono text-sm" value={item.value} readOnly />
          </div>
        ))}
      </div>
    </div>
  )
}

