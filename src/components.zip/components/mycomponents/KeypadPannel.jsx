export function KeypadPanel() {
    const instructions = [
      ["ACI", "ADC", "ADD", "ADI"],
      ["ANA", "ANI", "CALL", "CC"],
      ["CM", "CMA", "CMC", "CMP"],
      ["CNC", "CNZ", "CP", "CPE"],
      ["CPI", "CPO", "CZ", "DAA"],
      ["DAD", "DCR", "DCX", "DI"],
      ["EI", "HLT", "IN", "INR"],
      ["JNX", "JC", "JM", "JMP"],
      ["JNC", "JNZ", "JP", "JPE"],
      ["JPO", "JZ", "LDA", "LDAX"],
      ["LHLD", "LXI", "MOV", "MVI"],
      ["NOP", "ORA", "ORI", "OUT"],
      ["PCHL", "RNZ", "POP", "PUSH"],
    ]
  
    return (
      <div className="grid grid-cols-4 gap-1 p-2">
        {instructions.map((row, i) => (
          row.map((instruction, j) => (
            <button
              key={`${i}-${j}`}
              className="p-2 text-xs font-mono bg-muted hover:bg-accent rounded"
            >
              {instruction}
            </button>
          ))
        ))}
      </div>
    )
  }
  
  