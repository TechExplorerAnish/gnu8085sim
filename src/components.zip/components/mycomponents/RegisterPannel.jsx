import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function RegistersPanel() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">Registers</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-2 text-sm">
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">A</div>
          <div className="font-mono col-span-2">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">BC</div>
          <div className="font-mono">00</div>
          <div className="font-mono">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">DE</div>
          <div className="font-mono">00</div>
          <div className="font-mono">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">HL</div>
          <div className="font-mono">00</div>
          <div className="font-mono">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">PSW</div>
          <div className="font-mono">00</div>
          <div className="font-mono">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">PC</div>
          <div className="font-mono">00</div>
          <div className="font-mono">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">SP</div>
          <div className="font-mono">00</div>
          <div className="font-mono">00</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="font-mono">Int-Reg</div>
          <div className="font-mono col-span-2">00</div>
        </div>
      </CardContent>
    </Card>
  )
}

